from pathlib import Path
import subprocess
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def test_transform_produces_valid_orders():
    subprocess.run([sys.executable, str(ROOT / "src" / "transform.py")], check=True)
    orders = pd.read_csv(ROOT / "data" / "processed" / "fact_orders.csv")
    assert orders["order_id"].is_unique
    assert (orders["quantity"] > 0).all()
    assert (orders["revenue"] >= 0).all()
