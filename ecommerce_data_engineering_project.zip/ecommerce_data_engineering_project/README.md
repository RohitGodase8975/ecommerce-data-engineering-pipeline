# E-Commerce Data Engineering Pipeline (Portfolio Project)

An entry-level, end-to-end portfolio project demonstrating ingestion, cleaning, batch processing, warehouse modeling, orchestration, and data quality.

## Architecture

CSV/API-style source data → Python ingestion & validation → raw zone (CSV/Parquet) → PySpark transformations → BigQuery warehouse (cloud target) → dbt models/tests → Airflow orchestration → Looker Studio dashboard.

**Local-first note:** This repository includes a runnable local starter pipeline and example files for the cloud pieces. BigQuery, Cloud Storage, Airflow, dbt, and PySpark require separate setup before their integrations can run end-to-end. Do not claim cloud deployment until you have actually deployed and tested it.

## Stack and languages

- Python: ingestion, validation, transformation, tests
- SQL / GoogleSQL: analytics and warehouse queries
- PySpark: scalable batch transformations
- Apache Airflow: workflow orchestration (DAG example)
- dbt Core: warehouse transformations, tests, documentation
- Google Cloud Storage (GCS): raw/landing storage target
- BigQuery: analytical warehouse target
- Docker + Docker Compose: reproducible local services
- Bash + YAML: automation and configuration
- Git/GitHub: version control
- Optional extension: Pub/Sub + Dataflow for streaming

## Data

Small synthetic e-commerce datasets are included:
- `data/raw/orders.csv`
- `data/raw/customers.csv`
- `data/raw/products.csv`

The sample data is fictional and intended for learning.

## Quick start (local Python pipeline)

Requirements: Python 3.10+.

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\\Scripts\\Activate.ps1

pip install -r requirements.txt
python src/ingest.py
python src/transform.py
python src/quality_checks.py
```

Outputs are written to `data/processed/`. This local path does not require cloud credentials.

## Build plan

1. **Python + files:** ingest raw CSVs, log row counts, validate required columns.
2. **Data quality:** reject invalid orders, normalize dates, detect duplicates and nulls.
3. **PySpark:** scale the transformation to larger data volumes.
4. **BigQuery:** create `raw`, `staging`, and `analytics` datasets and load the data.
5. **dbt:** create staging and mart models, then add tests.
6. **Airflow:** schedule the ingestion → quality → transformation → warehouse/dbt tasks.
7. **Dashboard:** connect Looker Studio to the final mart tables.
8. **CI:** add GitHub Actions to run Python tests and SQL/dbt checks.

## Suggested warehouse model

- `dim_customers`: one row per customer
- `dim_products`: one row per product
- `fact_orders`: one row per order item (or one row per order if you adapt the grain)
- `mart_daily_sales`: revenue and order counts by date
- `mart_product_performance`: revenue and units sold by product

## Resume bullet (use only after implementing and testing)

**E-Commerce Data Engineering Pipeline | Python, SQL, PySpark, Airflow, dbt, GCP BigQuery**
- Built a batch ETL pipeline to ingest and validate e-commerce order, customer, and product data using Python.
- Developed transformation and data-quality checks for duplicate IDs, missing values, invalid quantities, and revenue consistency.
- Modeled analytics-ready sales and product marts with SQL/dbt and designed an Airflow DAG to orchestrate pipeline stages.
- Prepared a GCP architecture using Cloud Storage and BigQuery for scalable storage and analytics.

Replace generic claims with measured results from your own execution (e.g., rows processed, failed records, runtime). Do not invent performance numbers.

## Repository structure

```text
.
├── data/
│   ├── raw/
│   └── processed/
├── dags/
│   └── ecommerce_pipeline.py
├── dbt_project/
│   ├── dbt_project.yml
│   └── models/
│       ├── staging/
│       └── marts/
├── sql/
│   └── bigquery_setup.sql
├── src/
│   ├── ingest.py
│   ├── transform.py
│   └── quality_checks.py
├── tests/
├── requirements.txt
└── README.md
```

## Official learning links

- BigQuery: https://docs.cloud.google.com/bigquery/docs/
- BigQuery load/query quickstart: https://docs.cloud.google.com/bigquery/docs/quickstarts/load-data-console
- Airflow first workflow: https://airflow.apache.org/docs/apache-airflow/stable/tutorial/fundamentals.html
- Airflow simple pipeline: https://airflow.apache.org/docs/apache-airflow/stable/tutorial/pipeline.html
- dbt quickstarts: https://docs.getdbt.com/docs/get-started-dbt
- Pub/Sub → Dataflow quickstart (optional streaming): https://docs.cloud.google.com/pubsub/docs/stream-messages-dataflow
