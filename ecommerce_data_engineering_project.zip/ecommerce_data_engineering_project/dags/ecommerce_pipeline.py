"""
Airflow DAG template.
This example assumes Airflow can access this repository and Python dependencies
are installed in the Airflow environment. Start by testing the local scripts.
"""
from datetime import datetime
from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="ecommerce_daily_pipeline",
    start_date=datetime(2026, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["portfolio", "ecommerce", "etl"],
) as dag:
    ingest = BashOperator(
        task_id="ingest_csv",
        bash_command="python /opt/airflow/project/src/ingest.py",
    )
    transform = BashOperator(
        task_id="transform_data",
        bash_command="python /opt/airflow/project/src/transform.py",
    )
    quality = BashOperator(
        task_id="quality_checks",
        bash_command="python /opt/airflow/project/src/quality_checks.py",
    )
    ingest >> transform >> quality
