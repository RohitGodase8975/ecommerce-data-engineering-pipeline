from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

def main():
    for name in ("orders", "customers", "products"):
        df = pd.read_csv(RAW / f"{name}.csv")
        df.to_csv(OUT / f"{name}_ingested.csv", index=False)
        print(f"{name}: ingested {len(df)} rows")

if __name__ == "__main__":
    main()
