from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

def main():
    orders = pd.read_csv(RAW / "orders.csv")
    orders = orders.drop_duplicates(subset=["order_id"])
    orders["order_date"] = pd.to_datetime(orders["order_date"], errors="coerce")
    orders["quantity"] = pd.to_numeric(orders["quantity"], errors="coerce")
    orders["unit_price"] = pd.to_numeric(orders["unit_price"], errors="coerce")

    valid = (
        orders["order_id"].notna()
        & orders["customer_id"].notna()
        & orders["product_id"].notna()
        & orders["order_date"].notna()
        & orders["quantity"].gt(0)
        & orders["unit_price"].ge(0)
        & orders["status"].eq("completed")
    )
    clean = orders.loc[valid].copy()
    clean["revenue"] = clean["quantity"] * clean["unit_price"]
    clean["order_date"] = clean["order_date"].dt.strftime("%Y-%m-%d")
    clean.to_csv(OUT / "fact_orders.csv", index=False)

    customers = pd.read_csv(RAW / "customers.csv").drop_duplicates("customer_id")
    products = pd.read_csv(RAW / "products.csv").drop_duplicates("product_id")
    customers.to_csv(OUT / "dim_customers.csv", index=False)
    products.to_csv(OUT / "dim_products.csv", index=False)

    daily = clean.groupby("order_date", as_index=False).agg(
        order_count=("order_id", "nunique"),
        units_sold=("quantity", "sum"),
        revenue=("revenue", "sum"),
    )
    daily.to_csv(OUT / "mart_daily_sales.csv", index=False)
    print(f"Clean orders: {len(clean)}; daily sales rows: {len(daily)}")

if __name__ == "__main__":
    main()
