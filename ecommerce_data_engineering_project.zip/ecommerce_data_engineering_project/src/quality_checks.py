from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "processed"

def main():
    orders = pd.read_csv(DATA / "fact_orders.csv")
    required = ["order_id", "customer_id", "product_id", "order_date", "quantity", "unit_price", "revenue"]
    assert all(c in orders.columns for c in required), "Required columns missing"
    assert orders["order_id"].is_unique, "Duplicate order_id detected"
    assert orders[required].notna().all().all(), "Nulls found in required fields"
    assert (orders["quantity"] > 0).all(), "Non-positive quantity found"
    assert (orders["unit_price"] >= 0).all(), "Negative unit price found"
    assert (orders["revenue"] >= 0).all(), "Negative revenue found"
    print("PASS: data quality checks")
    print(f"Validated {len(orders)} order rows")

if __name__ == "__main__":
    main()
