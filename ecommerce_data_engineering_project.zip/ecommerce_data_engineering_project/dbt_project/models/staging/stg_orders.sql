-- Adapt source() configuration after connecting dbt to your warehouse.
select
    cast(order_id as int64) as order_id,
    cast(customer_id as int64) as customer_id,
    cast(product_id as int64) as product_id,
    cast(order_date as date) as order_date,
    cast(quantity as int64) as quantity,
    cast(unit_price as numeric) as unit_price,
    cast(quantity as numeric) * cast(unit_price as numeric) as revenue
from {{ source('raw', 'orders') }}
where status = 'completed'
  and cast(quantity as int64) > 0
