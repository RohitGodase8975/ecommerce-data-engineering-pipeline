select
    order_date,
    count(distinct order_id) as order_count,
    sum(quantity) as units_sold,
    sum(revenue) as revenue
from {{ ref('stg_orders') }}
group by order_date
