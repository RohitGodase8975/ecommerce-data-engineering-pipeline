-- Run in BigQuery after selecting your Google Cloud project.
-- Replace YOUR_PROJECT_ID with your actual project ID.
CREATE SCHEMA IF NOT EXISTS `YOUR_PROJECT_ID.raw`;
CREATE SCHEMA IF NOT EXISTS `YOUR_PROJECT_ID.staging`;
CREATE SCHEMA IF NOT EXISTS `YOUR_PROJECT_ID.analytics`;

-- Example analytical query after loading a cleaned fact_orders table:
SELECT
  order_date,
  COUNT(DISTINCT order_id) AS order_count,
  SUM(quantity) AS units_sold,
  SUM(revenue) AS revenue
FROM `YOUR_PROJECT_ID.analytics.fact_orders`
GROUP BY order_date
ORDER BY order_date;
